<?php

 include 'koneksi.php';
  $id = $_POST['id'];
  $kodepesawat = $_POST['kode_pesawat'];
  $namapesawat = $_POST['nama_pesawat'];
  $pilot = $_POST['pilot'];
  $kelaskabin = $_POST['kelas_kabin'];
  $harga = $_POST['harga'];



  mysqli_query($dbconnect, "UPDATE `admin` SET `kode_pesawat`='$kodepesawat' , `nama_pesawat`='$namapesawat' , `pilot`='$pilot' , `kelas_kabin`='$kelaskabin', `harga`='$harga' WHERE `id`='$id' ");
  header("location:databarang.php");
  ?>