<?php

include 'koneksi.php';

$user = $_POST['user'];
$email= $_POST['email'];
$password= $_POST['password'];



 mysqli_query($dbconnect, "INSERT INTO akun VALUES ( NULL, '$user','$email','$password')");

 header("location:dataakun.php")
 ?>
